const crypto = require('crypto');
const axios = require('axios');

// Your Flow JSON - paste your entire Flow JSON here
const FLOW_JSON = {
  "data": {
    "version": "4.0",
    "screen": {
      "id": "SCREEN_1",
      "body": {
        "type": "vertical",
        "children": [
          {
            "type": "text",
            "text": "Welcome to Food Order Service!",
            "style": {
              "font_size": "large",
              "bold": true
            }
          },
          {
            "type": "text",
            "text": "We're processing your order with Flow ID: 1631942710832856"
          },
          {
            "type": "button",
            "text": "Track Order",
            "on_click": {
              "action": "navigate",
              "navigate": {
                "flow_id": "1631942710832856",
                "data": {
                  "order_status": "processing"
                }
              }
            }
          }
        ]
      }
    }
  }
};

// Environment variables
const CONFIG = {
  FLOW_ID: "1631942710832856",
  VERIFY_TOKEN: process.env.VERIFY_TOKEN,
  ACCESS_TOKEN: process.env.ACCESS_TOKEN,
  PHONE_NUMBER_ID: process.env.PHONE_NUMBER_ID,
  APP_SECRET: process.env.APP_SECRET
};

class WhatsAppFlowHandler {
  constructor() {
    this.flowJson = FLOW_JSON;
  }

  // Verify webhook subscription
  verifyWebhook(queryParams) {
    const mode = queryParams['hub.mode'];
    const token = queryParams['hub.verify_token'];
    const challenge = queryParams['hub.challenge'];

    if (mode === 'subscribe' && token === CONFIG.VERIFY_TOKEN) {
      return parseInt(challenge);
    }
    return null;
  }

  // Verify incoming webhook signature
  verifySignature(payload, signature) {
    const expectedSignature = crypto
      .createHmac('sha256', CONFIG.APP_SECRET)
      .update(payload)
      .digest('hex');
    
    return `sha256=${expectedSignature}` === signature;
  }

  // Send WhatsApp message
  async sendWhatsAppMessage(to, message) {
    try {
      const url = `https://graph.facebook.com/v18.0/${CONFIG.PHONE_NUMBER_ID}/messages`;
      
      const payload = {
        messaging_product: "whatsapp",
        to: to,
        text: { body: message }
      };

      const response = await axios.post(url, payload, {
        headers: {
          'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      console.error('Error sending WhatsApp message:', error.response?.data || error.message);
      throw error;
    }
  }

  // Send Flow message
  async sendFlowMessage(to, flowToken = null) {
    try {
      const url = `https://graph.facebook.com/v18.0/${CONFIG.PHONE_NUMBER_ID}/messages`;
      
      const payload = {
        messaging_product: "whatsapp",
        to: to,
        type: "interactive",
        interactive: {
          type: "flow",
          header: {
            type: "text",
            text: "Food Order Status"
          },
          body: {
            text: "Track your food order in real-time"
          },
          footer: {
            text: `Flow ID: ${CONFIG.FLOW_ID}`
          },
          action: {
            name: "flow",
            parameters: {
              flow_message_version: "4.0",
              flow_token: flowToken || this.generateFlowToken(),
              flow_id: CONFIG.FLOW_ID,
              flow_cta: "Track Order",
              flow_action: "navigate",
              flow_action_payload: {
                screen: "SCREEN_1"
              }
            }
          }
        }
      };

      const response = await axios.post(url, payload, {
        headers: {
          'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data;
    } catch (error) {
      console.error('Error sending Flow message:', error.response?.data || error.message);
      throw error;
    }
  }

  // Generate flow token
  generateFlowToken() {
    return `flow_token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Process incoming message
  async processIncomingMessage(webhookData) {
    try {
      const entry = webhookData.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      const messages = value?.messages;

      if (!messages || messages.length === 0) {
        return { status: 'no_message' };
      }

      const message = messages[0];
      const fromNumber = message.from;
      const messageType = message.type;

      if (messageType === 'text') {
        const messageText = message.text.body;
        
        // Send acknowledgment first
        await this.sendWhatsAppMessage(fromNumber, "🔄 Processing your request...");
        
        // Then send the Flow
        const flowResult = await this.sendFlowMessage(fromNumber);
        
        return {
          status: 'success',
          flow_sent: true,
          customer_number: fromNumber,
          flow_id: CONFIG.FLOW_ID,
          message: `Responded to: "${messageText}"`
        };
      } else {
        // For non-text messages, send instructions
        await this.sendWhatsAppMessage(
          fromNumber, 
          "📱 Please send a text message to receive the order tracking flow."
        );
        return { status: 'non_text_message' };
      }
    } catch (error) {
      console.error('Error processing message:', error);
      throw error;
    }
  }
}

// Main Lambda handler
exports.handler = async (event, context) => {
  console.log('Received event:', JSON.stringify(event, null, 2));
  
  const flowHandler = new WhatsAppFlowHandler();

  try {
    // Handle webhook verification
    if (event.queryStringParameters) {
      const challenge = flowHandler.verifyWebhook(event.queryStringParameters);
      if (challenge !== null) {
        return {
          statusCode: 200,
          body: challenge.toString()
        };
      } else {
        return {
          statusCode: 403,
          body: 'Verification failed'
        };
      }
    }

    // Handle incoming messages
    if (event.httpMethod === 'POST') {
      // Verify signature for security
      const signature = event.headers['x-hub-signature-256'];
      const body = event.body;
      
      if (signature && !flowHandler.verifySignature(body, signature)) {
        return {
          statusCode: 401,
          body: JSON.stringify({ error: 'Invalid signature' })
        };
      }

      const webhookData = typeof body === 'string' ? JSON.parse(body) : body;
      const result = await flowHandler.processIncomingMessage(webhookData);

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(result)
      };
    }

    // Health check for Lambda URL
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        status: 'healthy',
        flow_id: CONFIG.FLOW_ID,
        message: 'WhatsApp Flow Handler is running'
      })
    };

  } catch (error) {
    console.error('Lambda handler error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};